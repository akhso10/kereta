# Perpustakaan aset Arunika 13

Buka Katalog.html setelah mengekstrak folder lengkap. Setiap gambar memiliki file PNG tersendiri dan catatan di Panduan_per_aset. Folder 01–11 berisi 67 gambar bernomor. Gambar 01–45 merupakan referensi visual dan prop generatif. Gambar 46–52 adalah layer efek transparan. Gambar 53–59 ditangkap langsung dari UI Godot. Gambar 60–67 adalah peta warna bahan prosedural. Master persegi berukuran 2048 × 2048 dan landscape 3840 × 2160. Gambar generatif dan tangkapan UI telah di-resample ke ukuran distribusi.

Folder 12 menyimpan model GLB individual dengan UV dan material. Berkas Blender mengelompokkan model dalam koleksi dengan nama yang sama. Setiap koleksi bisa diisolasi di Outliner. Bagian lantai, peron, kursi, jendela, rel dan terowongan dapat diatur sebagai modul. Model produksi adalah geometri real-time untuk demo. Model, bahan dan pencahayaan mempunyai tingkat detail yang berbeda dari konsep sinematik.

Ketujuh karakter memiliki skeleton dan klip animasi. Folder 13 menyimpan AnimationLibrary Godot untuk rig pasangannya. Pada proyek, gunakan animasi yang tersemat di GLB atau pasang library pada AnimationPlayer yang menargetkan struktur node karakter yang sama.

Instans interaktif dengan Area3D dan tabrakan berada di scenes/objek dalam ZIP proyek. Material Godot siap pakai berada di runtime/material. Sampel gambar runtime sudah dioptimalkan terpisah dari master. Impor master yang diperlukan secara selektif.
