# Pengujian build

Godot 4.7.2 Standard dengan renderer GL Compatibility. Pengujian dilakukan pada Linux x86-64.

- Mengimpor project.godot dan meluncurkan scene utama. Enam scene bab dapat dimuat.
- Menguji tombol mulai, jeda, pengaturan, jurnal, inventaris, peta, simpan serta lanjutkan.
- Menavigasi Bab 1 dengan simulasi input WASD dan tombol E. Memeriksa percakapan, kedua meja peron, tiga ruang sayap barat dan ambang keluar dalam simulasi fisika.
- Pada enam bab, pengujian interaksi menempatkan pemain di dekat objek, mengarahkan kamera lalu mengirim tombol E. Mengambil barang, membaca tiga bukti, menolak pilihan arsip dan kode yang salah, lalu menyelesaikan panel dan enam jenis tugas meja dinas.
- Menguji patroli, inisiasi pengejaran, masuk dan keluar dari persembunyian. Menguji pemulihan posisi, bab serta pintu yang terbuka setelah simpan/muat.
- Menguji dua hasil pada meja sinyal terakhir. Antarmuka direkam melalui renderer OpenGL.
- Mengekspor Windows x64 memakai template rilis Godot yang checksum SHA-512-nya cocok dengan daftar resmi. Menjalankan kembali uji enam bab pada PCK akhir menggunakan runtime Godot Linux. EXE diperiksa sebagai PE32+ x86-64. Peluncuran native Windows dan durasi playtest manusia masih perlu diuji.
- Membuka perpustakaan .blend dengan Blender 4.3.2. Mengimpor GLB melalui Blender dan Godot, memeriksa geometri, koordinat UV, skeleton serta nama klip karakter. Setiap PNG master dibaca dan diverifikasi dimensinya.
