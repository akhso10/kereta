# 13 · Koridor Antar-Gerbong

File: 03_ENVIRONMENT/13_koridor_antar-gerbong.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
