# 29 · Senter

File: 08_ITEMS/29_senter.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
