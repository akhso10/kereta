# 24 · Hantu Wanita

File: 06_GHOSTS/24_hantu_wanita.png

Lembar tampak entitas untuk bentuk, kostum dan siluet.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
