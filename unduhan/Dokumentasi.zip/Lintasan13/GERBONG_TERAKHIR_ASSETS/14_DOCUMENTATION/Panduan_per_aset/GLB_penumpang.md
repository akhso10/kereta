# Model · Penumpang

GLB 2.0 dengan 27 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan penumpang.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi penumpang.

Rig humanoid. Klip animasi: turning, running, walking, idle. AnimationLibrary terpisah tersedia dalam 13_ANIMATIONS.
