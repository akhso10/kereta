# 16 · Terowongan Lintasan 13

File: 03_ENVIRONMENT/16_terowongan_lintasan_13.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
