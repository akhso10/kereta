# Model · Raka

GLB 2.0 dengan 28 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan raka.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi raka.

Rig humanoid. Klip animasi: turning, running, walking, idle. AnimationLibrary terpisah tersedia dalam 13_ANIMATIONS.
