# 65 · Tekstur Kain Kursi

File: 11_TEXTURES/65_tekstur_kain_kursi.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
