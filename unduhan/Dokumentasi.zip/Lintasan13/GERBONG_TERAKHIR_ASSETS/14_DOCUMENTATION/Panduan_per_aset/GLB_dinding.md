# Model · Dinding

GLB 2.0 dengan 1 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan dinding.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi dinding.
