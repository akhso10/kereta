# Model · Jam

GLB 2.0 dengan 16 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan jam.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi jam.

Untuk interaksi gunakan scenes/objek/jam.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
