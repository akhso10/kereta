# Model · Rel Modular

GLB 2.0 dengan 21 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan rel_modular.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi rel_modular.
