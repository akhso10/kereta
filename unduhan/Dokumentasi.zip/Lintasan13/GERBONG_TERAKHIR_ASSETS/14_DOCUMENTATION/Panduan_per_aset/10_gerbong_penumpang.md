# 10 · Gerbong Penumpang

File: 04_TRAIN/10_gerbong_penumpang.png

Referensi bentuk dan corak bodi rangkaian Arunika 13.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
