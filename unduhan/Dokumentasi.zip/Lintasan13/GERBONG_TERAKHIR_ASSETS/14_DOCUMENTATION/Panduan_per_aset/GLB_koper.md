# Model · Koper

GLB 2.0 dengan 6 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan koper.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi koper.

Untuk interaksi gunakan scenes/objek/koper.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
