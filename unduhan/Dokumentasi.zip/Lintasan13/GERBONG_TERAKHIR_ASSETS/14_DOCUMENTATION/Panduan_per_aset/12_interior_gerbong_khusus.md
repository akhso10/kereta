# 12 · Interior Gerbong Khusus

File: 03_ENVIRONMENT/12_interior_gerbong_khusus.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
