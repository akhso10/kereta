# 67 · Tekstur Dinding Gerbong

File: 11_TEXTURES/67_tekstur_dinding_gerbong.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
