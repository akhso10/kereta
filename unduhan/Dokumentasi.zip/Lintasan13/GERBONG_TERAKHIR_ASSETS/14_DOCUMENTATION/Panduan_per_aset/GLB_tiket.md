# Model · Tiket

GLB 2.0 dengan 7 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan tiket.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi tiket.

Untuk interaksi gunakan scenes/objek/tiket.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
