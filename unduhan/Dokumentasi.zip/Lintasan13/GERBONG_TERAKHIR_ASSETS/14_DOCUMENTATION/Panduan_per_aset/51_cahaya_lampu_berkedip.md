# 51 · Cahaya Lampu Berkedip

File: 09_VFX/51_cahaya_lampu_berkedip.png

Layer efek RGBA. Pada Godot gunakan StandardMaterial3D dengan Transparency Alpha atau Sprite3D.billboard.

PNG 2048 × 2048. Transparansi alpha. Dibuat prosedural pada kanvas 2048 × 2048.
