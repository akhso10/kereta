# 02 · Screenshot Interior Gerbong

File: 02_GAMEPLAY/02_screenshot_interior_gerbong.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
