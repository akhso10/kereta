# 28 · Kunci Besi Tua

File: 08_ITEMS/28_kunci_besi_tua.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
