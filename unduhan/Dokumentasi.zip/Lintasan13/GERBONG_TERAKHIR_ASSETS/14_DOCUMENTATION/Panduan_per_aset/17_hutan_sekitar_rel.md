# 17 · Hutan Sekitar Rel

File: 03_ENVIRONMENT/17_hutan_sekitar_rel.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
