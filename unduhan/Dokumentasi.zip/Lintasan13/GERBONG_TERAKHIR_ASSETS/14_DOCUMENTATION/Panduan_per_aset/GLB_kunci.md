# Model · Kunci

GLB 2.0 dengan 3 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan kunci.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi kunci.

Untuk interaksi gunakan scenes/objek/kunci.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
