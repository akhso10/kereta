# 11 · Interior Gerbong Ekonomi

File: 03_ENVIRONMENT/11_interior_gerbong_ekonomi.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
