# 34 · Jam Saku

File: 08_ITEMS/34_jam_saku.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
