# Model · Bayangan

GLB 2.0 dengan 26 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan bayangan.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi bayangan.

Rig humanoid. Klip animasi: menghilang, muncul, turning, running, walking, idle. AnimationLibrary terpisah tersedia dalam 13_ANIMATIONS.
