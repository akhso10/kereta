# 30 · Tiket Kereta

File: 08_ITEMS/30_tiket_kereta.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
