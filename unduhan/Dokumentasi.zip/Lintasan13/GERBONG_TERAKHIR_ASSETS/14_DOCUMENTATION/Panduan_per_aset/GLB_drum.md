# Model · Drum

GLB 2.0 dengan 5 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan drum.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi drum.

Untuk interaksi gunakan scenes/objek/drum.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
