# Model · Panel Masinis

GLB 2.0 dengan 16 mesh dan 5 material. UV tersemat. Satuan meter.

Di Godot, masukkan panel_masinis.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi panel_masinis.
