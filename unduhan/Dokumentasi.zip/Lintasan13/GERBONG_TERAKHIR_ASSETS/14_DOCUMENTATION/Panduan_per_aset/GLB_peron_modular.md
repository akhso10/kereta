# Model · Peron Modular

GLB 2.0 dengan 5 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan peron_modular.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi peron_modular.
