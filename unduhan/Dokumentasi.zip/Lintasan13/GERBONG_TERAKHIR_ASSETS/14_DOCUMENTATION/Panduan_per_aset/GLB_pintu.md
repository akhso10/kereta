# Model · Pintu

GLB 2.0 dengan 3 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan pintu.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi pintu.

Untuk interaksi gunakan scenes/objek/pintu.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
