# 35 · Lentera Minyak

File: 07_PROPS/35_lentera_minyak.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
