# 05 · Screenshot Terowongan

File: 02_GAMEPLAY/05_screenshot_terowongan.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
