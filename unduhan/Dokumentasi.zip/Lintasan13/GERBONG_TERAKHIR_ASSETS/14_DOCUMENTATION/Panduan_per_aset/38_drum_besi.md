# 38 · Drum Besi

File: 07_PROPS/38_drum_besi.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
