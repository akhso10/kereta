# Model · Lengkung Terowongan

GLB 2.0 dengan 62 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan lengkung_terowongan.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi lengkung_terowongan.
