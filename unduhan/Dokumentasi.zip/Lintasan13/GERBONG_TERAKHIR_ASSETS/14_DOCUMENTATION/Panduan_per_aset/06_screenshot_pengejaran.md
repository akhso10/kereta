# 06 · Screenshot Pengejaran

File: 02_GAMEPLAY/06_screenshot_pengejaran.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
