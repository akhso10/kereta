# Model · Sekering

GLB 2.0 dengan 5 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan sekering.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi sekering.

Untuk interaksi gunakan scenes/objek/sekering.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
