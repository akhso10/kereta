# Model · Mira

GLB 2.0 dengan 29 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan mira.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi mira.

Rig humanoid. Klip animasi: turning, running, walking, idle. AnimationLibrary terpisah tersedia dalam 13_ANIMATIONS.
