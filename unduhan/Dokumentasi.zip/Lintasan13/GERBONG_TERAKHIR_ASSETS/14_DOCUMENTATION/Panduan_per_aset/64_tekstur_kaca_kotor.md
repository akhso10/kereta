# 64 · Tekstur Kaca Kotor

File: 11_TEXTURES/64_tekstur_kaca_kotor.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
