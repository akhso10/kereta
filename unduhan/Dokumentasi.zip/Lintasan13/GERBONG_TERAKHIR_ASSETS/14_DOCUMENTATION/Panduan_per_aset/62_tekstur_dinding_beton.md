# 62 · Tekstur Dinding Beton

File: 11_TEXTURES/62_tekstur_dinding_beton.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
