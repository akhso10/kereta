# Model · Radio

GLB 2.0 dengan 15 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan radio.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi radio.

Untuk interaksi gunakan scenes/objek/radio.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
