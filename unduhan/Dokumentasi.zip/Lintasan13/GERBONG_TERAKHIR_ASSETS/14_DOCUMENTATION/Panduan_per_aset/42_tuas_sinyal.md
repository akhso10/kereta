# 42 · Tuas Sinyal

File: 07_PROPS/42_tuas_sinyal.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
