# Model · Peti

GLB 2.0 dengan 3 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan peti.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi peti.

Untuk interaksi gunakan scenes/objek/peti.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
