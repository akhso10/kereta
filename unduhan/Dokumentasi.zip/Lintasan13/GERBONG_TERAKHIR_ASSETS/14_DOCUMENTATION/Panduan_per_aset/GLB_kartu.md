# Model · Kartu

GLB 2.0 dengan 7 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan kartu.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi kartu.

Untuk interaksi gunakan scenes/objek/kartu.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
