# Model · Lampu Peron

GLB 2.0 dengan 4 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan lampu_peron.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi lampu_peron.
