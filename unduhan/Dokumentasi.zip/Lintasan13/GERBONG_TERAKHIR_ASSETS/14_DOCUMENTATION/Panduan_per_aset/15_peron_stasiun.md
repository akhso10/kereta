# 15 · Peron Stasiun

File: 03_ENVIRONMENT/15_peron_stasiun.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
