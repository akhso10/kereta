# 27 · Penumpang Misterius

File: 05_CHARACTERS/27_penumpang_misterius.png

Lembar tampak karakter untuk pemodelan dan peninjauan kostum.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
