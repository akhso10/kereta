# 26 · Penjaga Terowongan

File: 06_GHOSTS/26_penjaga_terowongan.png

Lembar tampak entitas untuk bentuk, kostum dan siluet.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
