# 53 · Main Menu

File: 10_UI_HUD/53_main_menu.png

Tangkapan layar antarmuka dari proyek Godot saat dimainkan.

PNG 3840 × 2160. RGB. Ditangkap dari gameplay di Godot, lalu diperbesar ke kanvas distribusi.
