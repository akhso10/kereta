# 33 · Radio Lama

File: 07_PROPS/33_radio_lama.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
