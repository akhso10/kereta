# 32 · Koper Penumpang

File: 07_PROPS/32_koper_penumpang.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
