# 61 · Tekstur Kayu Tua

File: 11_TEXTURES/61_tekstur_kayu_tua.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
