# 40 · Peta Jalur Kereta

File: 08_ITEMS/40_peta_jalur_kereta.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
