# 07 · Screenshot Ruang Sinyal

File: 02_GAMEPLAY/07_screenshot_ruang_sinyal.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
