# 01 · Cover Utama Game

File: 01_COVER/01_cover_utama_game.png

Sampul utama untuk halaman distribusi. Judul sudah menjadi bagian gambar.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
