# 18 · Jembatan Kereta

File: 03_ENVIRONMENT/18_jembatan_kereta.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
