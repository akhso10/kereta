# Model · Jembatan Modular

GLB 2.0 dengan 28 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan jembatan_modular.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi jembatan_modular.
