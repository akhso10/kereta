# Model · Senter

GLB 2.0 dengan 7 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan senter.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi senter.

Untuk interaksi gunakan scenes/objek/senter.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
