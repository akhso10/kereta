# 09 · Lokomotif Arunika 13

File: 04_TRAIN/09_lokomotif_arunika_13.png

Referensi bentuk dan corak bodi rangkaian Arunika 13.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
