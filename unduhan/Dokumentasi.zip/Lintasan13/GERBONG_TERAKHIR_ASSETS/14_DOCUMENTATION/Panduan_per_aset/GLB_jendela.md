# Model · Jendela

GLB 2.0 dengan 5 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan jendela.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi jendela.
