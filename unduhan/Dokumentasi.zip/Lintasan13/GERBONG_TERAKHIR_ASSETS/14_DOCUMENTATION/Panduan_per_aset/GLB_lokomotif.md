# Model · Lokomotif

GLB 2.0 dengan 62 mesh dan 6 material. UV tersemat. Satuan meter.

Di Godot, masukkan lokomotif.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi lokomotif.
