# Model · Buku

GLB 2.0 dengan 2 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan buku.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi buku.

Untuk interaksi gunakan scenes/objek/buku.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
