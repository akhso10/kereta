# 25 · Bayangan Penumpang

File: 06_GHOSTS/25_bayangan_penumpang.png

Lembar tampak entitas untuk bentuk, kostum dan siluet.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
