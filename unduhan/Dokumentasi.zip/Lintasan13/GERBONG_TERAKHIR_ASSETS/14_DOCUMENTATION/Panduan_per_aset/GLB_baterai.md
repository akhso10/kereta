# Model · Baterai

GLB 2.0 dengan 6 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan baterai.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi baterai.

Untuk interaksi gunakan scenes/objek/baterai.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
