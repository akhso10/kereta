# 58 · Pause Menu

File: 10_UI_HUD/58_pause_menu.png

Tangkapan layar antarmuka dari proyek Godot saat dimainkan.

PNG 3840 × 2160. RGB. Ditangkap dari gameplay di Godot, lalu diperbesar ke kanvas distribusi.
