# Model · Gerbong

GLB 2.0 dengan 39 mesh dan 6 material. UV tersemat. Satuan meter.

Di Godot, masukkan gerbong.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi gerbong.
