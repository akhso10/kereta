# 14 · Stasiun Kota

File: 03_ENVIRONMENT/14_stasiun_kota.png

Referensi lokasi untuk penataan scene 3D.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
