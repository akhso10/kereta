# Model · Kursi

GLB 2.0 dengan 8 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan kursi.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi kursi.
