# 36 · Kotak Perkakas

File: 07_PROPS/36_kotak_perkakas.png

Prop terisolasi untuk panel pemeriksaan atau thumbnail inventaris.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
