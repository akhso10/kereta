# Model · Perkakas

GLB 2.0 dengan 6 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan perkakas.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi perkakas.

Untuk interaksi gunakan scenes/objek/perkakas.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
