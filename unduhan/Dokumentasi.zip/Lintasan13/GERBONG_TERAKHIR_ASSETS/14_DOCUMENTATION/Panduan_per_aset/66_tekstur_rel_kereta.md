# 66 · Tekstur Rel Kereta

File: 11_TEXTURES/66_tekstur_rel_kereta.png

Peta warna permukaan. Gunakan pada albedo StandardMaterial3D. Atur roughness dan metallic secara terpisah.

PNG 2048 × 2048. RGB. Dibuat prosedural pada kanvas 2048 × 2048.
