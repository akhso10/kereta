# 23 · Pak Darma

File: 05_CHARACTERS/23_pak_darma.png

Lembar tampak karakter untuk pemodelan dan peninjauan kostum.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
