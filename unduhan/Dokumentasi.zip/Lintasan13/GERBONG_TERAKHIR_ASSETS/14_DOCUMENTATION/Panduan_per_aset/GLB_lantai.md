# Model · Lantai

GLB 2.0 dengan 1 mesh dan 1 material. UV tersemat. Satuan meter.

Di Godot, masukkan lantai.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi lantai.
