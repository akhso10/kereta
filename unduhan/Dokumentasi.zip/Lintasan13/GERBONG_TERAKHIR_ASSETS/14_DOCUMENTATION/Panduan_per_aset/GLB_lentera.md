# Model · Lentera

GLB 2.0 dengan 9 mesh dan 4 material. UV tersemat. Satuan meter.

Di Godot, masukkan lentera.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi lentera.

Untuk interaksi gunakan scenes/objek/lentera.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
