# 22 · Mira

File: 05_CHARACTERS/22_mira.png

Lembar tampak karakter untuk pemodelan dan peninjauan kostum.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
