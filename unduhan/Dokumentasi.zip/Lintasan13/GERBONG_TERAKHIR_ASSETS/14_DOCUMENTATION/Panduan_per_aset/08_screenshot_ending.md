# 08 · Screenshot Ending

File: 02_GAMEPLAY/08_screenshot_ending.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
