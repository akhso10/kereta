# Model · Botol

GLB 2.0 dengan 6 mesh dan 3 material. UV tersemat. Satuan meter.

Di Godot, masukkan botol.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi botol.

Untuk interaksi gunakan scenes/objek/botol.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
