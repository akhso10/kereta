# 39 · Kartu Akses

File: 08_ITEMS/39_kartu_akses.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
