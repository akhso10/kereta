# 43 · Botol Obat

File: 08_ITEMS/43_botol_obat.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
