# 04 · Screenshot Stasiun Terbengkalai

File: 02_GAMEPLAY/04_screenshot_stasiun_terbengkalai.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
