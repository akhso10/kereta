# 55 · Inventory

File: 10_UI_HUD/55_inventory.png

Tangkapan layar antarmuka dari proyek Godot saat dimainkan.

PNG 3840 × 2160. RGB. Ditangkap dari gameplay di Godot, lalu diperbesar ke kanvas distribusi.
