# 21 · Karakter Utama Raka

File: 05_CHARACTERS/21_karakter_utama_raka.png

Lembar tampak karakter untuk pemodelan dan peninjauan kostum.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
