# 41 · Sekering Listrik

File: 08_ITEMS/41_sekering_listrik.png

Item cerita terisolasi untuk inventaris dan dokumen permainan.

PNG 2048 × 2048. Transparansi alpha. Keluaran generatif disesuaikan ke kanvas distribusi.
