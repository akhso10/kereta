# 03 · Screenshot Kabin Masinis

File: 02_GAMEPLAY/03_screenshot_kabin_masinis.png

Referensi sinematik komposisi lokasi dan cahaya.

PNG 3840 × 2160. RGB. Keluaran generatif disesuaikan ke kanvas distribusi.
