# Model · Peta

GLB 2.0 dengan 5 mesh dan 2 material. UV tersemat. Satuan meter.

Di Godot, masukkan peta.glb sebagai child Node3D. Di Blender, buka perpustakaan Blender/Arunika_Library.blend dan pilih koleksi peta.

Untuk interaksi gunakan scenes/objek/peta.tscn. Area3D dan BoxShape3D mengikuti batas mesh.
