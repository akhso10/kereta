# Gerbong Terakhir · Lintasan 13

Demo horor orang pertama untuk Windows 64-bit. Mainkan sebagai Raka, petugas dinas malam Arunika 13. Pada pukul 23.47, satu nama hilang dari manifes kereta. Telusuri enam bab sampai ke meja sinyal untuk menentukan nasib penumpang.

## Mainkan di Windows

1. Unduh **Gerbong-Terakhir-Windows-x64.zip** dan ekstrak seluruh isinya ke satu folder.
2. Pastikan GerbongTerakhir.exe dan GerbongTerakhir.pck berada berdampingan. Jalankan GerbongTerakhir.exe.
3. Pilih **Mulai permainan**. Gunakan mouse dan keyboard. Game berjalan lokal. Untuk perangkat dengan GPU terbatas, matikan **Kualitas tinggi** dan pilih resolusi 1280 × 720 di Pengaturan.

## Buka proyek sumber

Gunakan Godot **4.7.2 Standard** untuk mencocokkan versi pengujian. Ekstrak ZIP proyek, buka Project Manager, pilih **Import**, dan pilih project.godot di folder Lintasan13. Tunggu impor GLB dan audio selesai lalu tekan **F6** pada Perjalanan.tscn atau **F5** dari editor. Blender 4.3.2 digunakan untuk membuat perpustakaan model.

Untuk membuat ulang build, pasang export templates yang cocok di editor. Buka **Project → Export → Windows Desktop**. Pilih folder output yang bisa ditulis, lalu ekspor EXE dan PCK bersama-sama.

## Kontrol

| Tindakan | Input |
| --- | --- |
| Melihat sekeliling | Mouse |
| Bergerak, berlari | W A S D, tahan Shift |
| Berbicara, mengambil, membaca, membuka pintu | Bidik objek dari dekat lalu tekan E |
| Berlindung atau keluar | E di koper dekat lemari persembunyian |
| Senter | F. Daya pulih perlahan saat dimatikan |
| Inventaris, jurnal, peta | I, J, M |
| Periksa tiga barang pertama | 1, 2, 3 |
| Jeda, simpan, pengaturan | Esc |
| Panel dan pilihan percakapan | Klik dengan mouse |

## Dari loket sampai ruang sinyal

Di Bab 1, dekati Pak Darma di sisi kiri peron. Kunci loket berada di meja kiri, sedangkan jadwal yang memuat kode keberangkatan ada di meja kanan. Bukaan pada dinding sisi barat mengarah ke loket dinas, arsip dan ruang tunggu. Periksa buku, radio dan surat di ketiga ruangan. Buka jurnal untuk membaca lagi dokumen yang ditemukan.

Setiap bab mempunyai pemeriksaan arsip, kode panel, dan tugas petugas. Di peron, putar keping wesel untuk menyambungkan arus dari A ke F. Bab selanjutnya memakai manifes kursi, penalaan radio, timbangan bagasi, sandi menara, dan prosedur keberangkatan. Setelah relai aktif, lewati ambang pintu, arahkan pandangan ke jalur keluar lalu tekan E. Di stasiun terakhir, pilih tujuan kereta.

Bayangan berpatroli di bab tertentu. Berlari dan menyalakan senter memudahkan bayangan menemukan Raka. Berlindung di balik bagasi untuk memutus pengejaran. Jika kondisi habis, ulangi bab atau muat simpanan. Simpan secara manual lewat menu Jeda. Simpanan menyimpan bab, bukti, posisi, kondisi dan pintu yang terbuka. Tugas meja dinas yang masih berlangsung dimulai kembali saat dimuat. File permainan terletak di folder user:// milik Godot, di bawah app_userdata pada Windows.

## Isi proyek

- scenes memuat Perjalanan.tscn dan enam scene bab yang bisa diedit sendiri.
- scripts memuat kontrol orang pertama, sistem permainan, logika meja dinas, data misi dan percakapan.
- runtime dan audio memuat sumber daya yang digunakan permainan. Musik, hujan, langkah, bisikan dan sinyal dibuat dengan sintesis.
- GERBONG_TERAKHIR_ASSETS memuat 67 gambar bernomor, model GLB, sumber Blender, animasi dan katalog penggunaan. Buka 14_DOCUMENTATION/Katalog.html setelah ekstraksi untuk menelusuri gambar individual.
- Folder master gambar dikecualikan dari impor otomatis agar editor dapat dibuka lebih cepat. Salin gambar pilihan ke folder runtime jika ingin memakainya langsung di Godot.
- Build ini adalah demo enam bab. Durasi bermain bergantung pada eksplorasi dan waktu memecahkan teka-teki. Pengujian fungsional otomatis menggunakan rute dan jawaban yang diketahui.
