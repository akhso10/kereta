extends Node3D

const BENCH = preload("res://scripts/meja_dinas.gd")
var bench
const ARSIP = preload("res://scripts/arsip.json")
const DATA = preload("res://scripts/bab.json")
const MODEL = "res://GERBONG_TERAKHIR_ASSETS/12_3D_MODELS/"
const SAVE = "user://perjalanan_v1.json"
const PREF = "user://pengaturan.cfg"
const GOLD = Color("#e0b57c")
const PALE = Color("#ece8db")
const RED = Color("#9e483e")
var chapter := 0
var level: Node3D
var player := CharacterBody3D.new()
var camera := Camera3D.new()
var lamp := SpotLight3D.new()
var atmosphere := Environment.new()
var hud := CanvasLayer.new()
var overlay := CanvasLayer.new()
var box: VBoxContainer
var chapter_label: Label
var mission_label: Label
var meters: Array[ProgressBar] = []
var meter: Label
var action_label: Label
var subtitle: Label
var music := AudioStreamPlayer.new()
var storm := AudioStreamPlayer.new()
var radio := AudioStreamPlayer3D.new()
var enemy: Node3D
var gate: StaticBody3D
var tags := {}
var flags := {}
var history: Array = []
var cargo: Array = []
var state := "menu"
var hiding := false
var stamina := 100.0
var battery := 100.0
var health := 100
var chase := false
var grace := 0.0
var clock := 0.0
var caption_left := 0.0
var noise_left := 0.0
var step_left := 0.0
var focus := ""
var pitch := 0.0
var mission: Array
var pref := ConfigFile.new()
var options := {"Volume utama":75.0,"Musik":45.0,"Efek suara":70.0,"Kecerahan":55.0,"Sensitivitas mouse":50.0,"Subtitle":true,"Layar penuh":false,"Kualitas tinggi":true,"Resolusi":"1280 × 720"}
var prior := "menu"
var marker := Vector3.ZERO

func _ready():
	atmosphere.background_mode = Environment.BG_COLOR
	atmosphere.background_color = Color("#101d27")
	atmosphere.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	atmosphere.ambient_light_color = Color("#a6bbcb")
	atmosphere.fog_enabled = true
	atmosphere.fog_light_color = Color("#354650")
	atmosphere.fog_density = 0.013
	var world := WorldEnvironment.new()
	world.environment = atmosphere
	add_child(world)
	add_child(player)
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.65
	col.shape = cap
	col.position.y = .83
	player.add_child(col)
	player.add_child(camera)
	camera.position.y = 1.54
	camera.near = .045
	lamp.position=Vector3(.19,-.09,-.11)
	camera.add_child(lamp)
	lamp.light_color = Color("#ffdda5")
	lamp.light_energy = 4.2
	lamp.spot_range = 19
	lamp.spot_angle = 29
	lamp.shadow_enabled = true
	add_child(hud)
	add_child(overlay)
	for bus in ["Musik", "Efek"]:
		AudioServer.add_bus()
		AudioServer.set_bus_name(AudioServer.bus_count-1,bus)
	for pair in [[music,"malam","Musik"],[storm,"hujan","Efek"],[radio,"sandi","Efek"]]:
		add_child(pair[0])
		pair[0].stream = load("res://audio/"+pair[1]+".wav")
		pair[0].bus = pair[2]
	music.play()
	radio.unit_size = 2.5
	radio.max_distance = 16
	if pref.load(PREF)==OK:
		for k in options: options[k]=pref.get_value("opsi",k,options[k])
	apply_options()
	main_menu()

func apply_options():
	for item in [["Master","Volume utama"],["Musik","Musik"],["Efek","Efek suara"]]:
		AudioServer.set_bus_volume_db(AudioServer.get_bus_index(item[0]),linear_to_db(maxf(.00001,options[item[1]]/100.0)))
	atmosphere.ambient_light_energy = .4 + options["Kecerahan"]/105.0
	lamp.shadow_enabled = options["Kualitas tinggi"]
	get_viewport().scaling_3d_scale = 1.0 if options["Kualitas tinggi"] else .72
	var full: bool = options["Layar penuh"]
	if DisplayServer.get_name()!="headless":
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if full else DisplayServer.WINDOW_MODE_WINDOWED)
		if not full:
			DisplayServer.window_set_size(Vector2i(1600,900) if options["Resolusi"]=="1600 × 900" else Vector2i(1280,720))
	for k in options: pref.set_value("opsi",k,options[k])
	pref.save(PREF)

func label(parent: Node, s: String, size: int, color: Color=PALE) -> Label:
	var l := Label.new()
	l.text=s
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	l.add_theme_constant_override("outline_size",3)
	parent.add_child(l)
	return l

func clear_layer(parent):
	for child in parent.get_children():
		parent.remove_child(child)
		child.queue_free()

func panel(kind:String, eyebrow:String, title:String, art:bool=false):
	state=kind
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	hud.visible=false
	clear_layer(overlay)
	var bg:=ColorRect.new()
	overlay.add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color=Color("#0d1418") if art else Color(.035,.052,.06,.96)
	if art or kind in ["inventory","journal","settings","pause","map","code","dialogue"]:
		var img:=TextureRect.new()
		bg.add_child(img)
		img.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		img.texture=load("res://runtime/menu.jpg") if art else load("res://runtime/lokasi%d.jpg"%[12,2,3,19,5,8][chapter])
		img.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		img.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
		var gradient:=Gradient.new()
		gradient.colors=PackedColorArray([Color(.02,.03,.035,.98),Color(.02,.03,.035,.88),Color(.02,.03,.035,.16 if art else .66)])
		gradient.offsets=PackedFloat32Array([0,.45,1])
		var tex:=GradientTexture2D.new()
		tex.gradient=gradient
		var veil:=TextureRect.new()
		bg.add_child(veil)
		veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		veil.texture=tex
	var scroll:=ScrollContainer.new()
	bg.add_child(scroll)
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left=68
	scroll.offset_top=44
	scroll.offset_right=-48
	scroll.offset_bottom=-24
	box=VBoxContainer.new()
	box.custom_minimum_size.x=610
	box.add_theme_constant_override("separation",9)
	scroll.add_child(box)
	label(box,eyebrow.to_upper(),17,GOLD)
	label(box,title,48)
	box.add_child(HSeparator.new())

func textline(s:String):
	var l:=label(box,s,18)
	l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART

func button(s:String,cb:Callable):
	var b:=Button.new()
	b.text=s
	b.alignment=HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size=Vector2(340,38)
	b.size_flags_horizontal=Control.SIZE_SHRINK_BEGIN
	var style:=StyleBoxFlat.new()
	style.bg_color=Color("#252e2f")
	style.border_width_left=3
	style.border_color=RED
	style.content_margin_left=14
	b.add_theme_stylebox_override("normal",style)
	b.add_theme_font_size_override("font_size",17)
	b.pressed.connect(cb)
	box.add_child(b)

func main_menu():
	storm.stop()
	radio.stop()
	panel("menu","ARUNIKA RAIL     /     DINAS MALAM 13","Gerbong Terakhir",true)
	textline("LINTASAN 13   ·   Stasiun Kota, pukul 23.47")
	button("Mulai permainan",new_game)
	button("Lanjutkan",load_game)
	box.get_child(-1).disabled=not FileAccess.file_exists(SAVE)
	button("Pengaturan",func(): settings("menu"))
	button("Kredit",credits)
	button("Keluar",func(): get_tree().quit())

func credits():
	panel("credits","Arunika Rail","Kredit")
	textline("Gerbong Terakhir: Lintasan 13\nCerita interaktif dan produksi aset untuk proyek kereta.\nGambar konsep generatif, model modular Blender, audio sintesis orisinal. Dibuat dengan Godot Engine.")
	button("Kembali",main_menu)

func settings(origin):
	prior=origin
	panel("settings","Preferensi pemain","Pengaturan")
	for key in options:
		var row:=HBoxContainer.new()
		box.add_child(row)
		var name_label:=label(row,key,16)
		name_label.custom_minimum_size.x=220
		if typeof(options[key])==TYPE_BOOL:
			var toggle:=CheckButton.new()
			row.add_child(toggle)
			toggle.button_pressed=options[key]
			toggle.toggled.connect(func(on): options[key]=on;apply_options())
		elif key=="Resolusi":
			var select:=OptionButton.new()
			row.add_child(select)
			for s in ["1280 × 720","1600 × 900"]:select.add_item(s)
			select.selected=1 if options[key]=="1600 × 900" else 0
			select.item_selected.connect(func(id):options[key]=select.get_item_text(id);apply_options())
		else:
			var slider:=HSlider.new()
			row.add_child(slider)
			slider.custom_minimum_size.x=210
			slider.value=options[key]
			slider.value_changed.connect(func(v):options[key]=v;apply_options())
	button("Kembali",func(): main_menu() if prior=="menu" else pause_menu())

func new_game():
	cargo=[]
	history=[]
	health=100
	start_chapter(0)

func start_chapter(index:int):
	if is_instance_valid(level):
		remove_child(level)
		level.queue_free()
	chapter=index
	bench=BENCH.new()
	bench.setup(self)
	mission=DATA.data[index]
	level=load("res://scenes/bab_%d.tscn"%(index+1)).instantiate()
	add_child(level)
	player.position=level.get_node("Spawn").position
	player.rotation=Vector3.ZERO
	camera.rotation=Vector3.ZERO
	pitch=0
	player.velocity=Vector3.ZERO
	flags={"item":false,"clue":false,"talk":false,"open":false}
	tags={"item":level.get_node("Item"),"clue":level.get_node("Clue"),"talk":level.get_node("Petugas"),"hide":level.get_node("Hide"),"console":level.get_node("Console"),"exit":level.get_node("Exit"),"door":level.get_node("Door")}
	for pair in [["reg","Register"],["voice","Saksi"],["paper","Arsip"]]:
		tags[pair[0]]=level.get_node(pair[1])
	tags.hide.rotation.y=.18
	var locker:=CSGBox3D.new()
	locker.size=Vector3(1.15,2.05,.82)
	locker.position=tags.hide.position+Vector3(0,1.025,-.65)
	var mat:=StandardMaterial3D.new()
	mat.albedo_color=Color("#4f5350")
	locker.material=mat
	level.add_child(locker)
	gate=StaticBody3D.new()
	level.add_child(gate)
	gate.position=tags.door.position
	var col:=CollisionShape3D.new()
	var shape:=BoxShape3D.new()
	shape.size=Vector3(2.1,3.1,.32)
	col.shape=shape
	col.position.y=1.55
	gate.add_child(col)
	enemy=null
	if index in [1,3,4,5]:
		enemy=load(MODEL+("penjaga" if index==4 else "hantu")+".glb").instantiate()
		level.add_child(enemy)
		enemy.position=Vector3(0,0,-19)
		animate(enemy,"walking")
	animate(tags.talk,"idle")
	clock=0
	grace=7
	chase=false
	hiding=false
	stamina=100
	battery=100
	lamp.visible=true
	radio.position=tags.console.position+Vector3.UP
	dress_level()
	radio.play()
	storm.play()
	hud_build()
	resume()
	say("Bab %d  ·  %s\nWASD berjalan · Shift lari · E interaksi · F senter · J jurnal"%[chapter+1,mission[0]],8)

func placard(path:String,pos:Vector3,dimensions:Vector2,yaw:float=0.0):
	var mesh:=MeshInstance3D.new()
	var quad:=QuadMesh.new()
	quad.size=dimensions
	var mat:=StandardMaterial3D.new()
	mat.albedo_texture=load(path)
	mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	mat.cull_mode=BaseMaterial3D.CULL_DISABLED
	quad.material=mat
	mesh.mesh=quad
	mesh.position=pos
	mesh.rotation.y=yaw
	level.add_child(mesh)

func decoration(model:String,pos:Vector3,yaw:float=0):
	var obj=load(MODEL+model+".glb").instantiate()
	obj.position=pos
	obj.rotation.y=yaw
	level.add_child(obj)
	return obj

func dress_level():
	if chapter in [1,2,3]:
		for z in range(5,-32,-3):
			for sign_x in [-1,1]:
				placard("res://runtime/kaca.jpg",Vector3(sign_x*2.085,1.43,z),Vector2(1.57,.86),-sign_x*PI/2)
	if chapter==4:
		for z in range(6,-46,-2):decoration("lengkung_terowongan",Vector3(0,0,z))
		for z in [-11,-17,-23]:
			decoration("jembatan_modular",Vector3(0,-.1,z))
	if chapter==2:
		for z in [-4,-13,-22]:decoration("panel_masinis",Vector3(-1.65,0,z),PI/2)
		for z in [-9,-26]:
			placard("res://runtime/kaca.jpg",Vector3(0,1.82,z),Vector2(1.62,.64))
	if chapter in [0,5]:
		placard("res://runtime/clock.png",Vector3(0,3.37,-4.3),Vector2(1.13,1.13))
		for z in [-6,-18,-30,-42]:
			decoration("lampu_peron",Vector3(5.5,0,z),PI)
		for z in [-3,-17,-33]:
			placard("res://runtime/denah.png",Vector3(-13.02,1.9,z),Vector2(1.74,1.6),PI/2)
		var rain:=CPUParticles3D.new()
		var drop:=BoxMesh.new()
		drop.size=Vector3(.009,.19,.009)
		var water:=StandardMaterial3D.new()
		water.albedo_color=Color(.29,.39,.47,.48)
		water.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
		drop.material=water
		rain.mesh=drop
		rain.amount=600
		rain.lifetime=.9
		rain.emission_shape=CPUParticles3D.EMISSION_SHAPE_BOX
		rain.emission_box_extents=Vector3(3,.2,25)
		rain.position=Vector3(9,5,-17)
		rain.direction=Vector3(-.12,-1,0)
		rain.spread=4
		rain.initial_velocity_min=6
		rain.initial_velocity_max=9
		level.add_child(rain)
	elif chapter==2:
		for z in [-4,-13,-22]:
			for j in 3:
				placard("res://runtime/gauge.png",Vector3(-1.11,1.01,z-.54+.46*j),Vector2(.42,.42),PI/2)
	# Collision keeps the furnishings solid while preserving the central aisle.
	for mesh in level.get_children():
		var id:=String(mesh.name)
		if id.begins_with("kursi") or id.begins_with("peti"):
			var body:=StaticBody3D.new()
			var coll:=CollisionShape3D.new()
			var shp:=BoxShape3D.new()
			shp.size=Vector3(1.1,.81,.55) if id.begins_with("kursi") else Vector3(.88,.64,.64)
			coll.position.y=shp.size.y/2
			coll.shape=shp
			body.add_child(coll)
			mesh.add_child(body)

func animate(model:Node,clip:String):
	for ap in model.find_children("*","AnimationPlayer",true,false):
		for anim in ap.get_animation_list():
			if clip in String(anim).to_lower():
				ap.get_animation(anim).loop_mode=Animation.LOOP_LINEAR
				ap.play(anim)
				return

func hud_build():
	clear_layer(hud)
	meters.clear()
	var c:=Control.new()
	hud.add_child(c)
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	chapter_label=label(c,"BAB %02d    /    %s"%[chapter+1,String(mission[0]).to_upper()],20,GOLD)
	chapter_label.position=Vector2(30,20)
	mission_label=label(c,"",17)
	mission_label.position=Vector2(30,51)
	var dot:=label(c,"·",24)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	action_label=label(c,"",19)
	action_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	action_label.offset_top=29
	action_label.offset_left=-210
	action_label.offset_right=210
	action_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var strip:=HBoxContainer.new()
	c.add_child(strip)
	strip.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	strip.offset_top=-78
	strip.offset_left=30
	strip.add_theme_constant_override("separation",15)
	for pair in [["KONDISI",Color("#af6155")],["STAMINA",Color("#e3bd83")],["BATERAI",Color("#8caaa2")]]:
		var col:=VBoxContainer.new()
		strip.add_child(col)
		label(col,pair[0],12)
		var bar:=ProgressBar.new()
		bar.show_percentage=false
		bar.custom_minimum_size=Vector2(105,5)
		var fill:=StyleBoxFlat.new()
		fill.bg_color=pair[1]
		bar.add_theme_stylebox_override("fill",fill)
		col.add_child(bar)
		meters.append(bar)
	meter=label(c,"",14)
	meter.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	meter.offset_top=-47
	meter.offset_left=30
	subtitle=label(c,"",18)
	subtitle.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	subtitle.offset_left=-540
	subtitle.offset_right=540
	subtitle.offset_top=-108
	subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER

func resume():
	clear_layer(overlay)
	state="play"
	hud.visible=true
	Input.mouse_mode=Input.MOUSE_MODE_CAPTURED
	update_hud()

func say(s:String,duration:float=4):
	if options["Subtitle"]:
		subtitle.text=s
		caption_left=duration

func objective()->String:
	if not flags.talk:return "Temui "+str(mission[10])+" di depan."
	if not flags.item:return "Ambil "+str(mission[2]).to_lower()+" di meja kiri."
	if not flags.clue:return "Baca "+str(mission[4]).to_lower()+" di meja kanan."
	for k in ["reg","voice","paper"]:
		if not flags.get(k,false):return "Selidiki "+str(ARSIP.data[chapter*2][["reg","voice","paper"].find(k)][0])+"  [M] denah"
	if not flags.open:return str(mission[9])+" di panel ujung."
	return "Lewati pintu untuk melanjutkan."

func update_hud():
	mission_label.text=objective()
	meters[0].value=health
	meters[1].value=stamina
	meters[2].value=battery
	meter.text="[I]  Inventaris     [J]  Jurnal     [M]  Peta     [Esc]  Jeda"
	if cargo.size()>0:meter.text+="        [1] "+str(cargo[0])
	if cargo.size()>1:meter.text+="    [2] "+str(cargo[1])
	if cargo.size()>2:meter.text+="    [3] "+str(cargo[2])
	action_label.text="E   Keluar dari persembunyian" if hiding else ""
	if not hiding and focus!="":
		var labels={"talk":"Bicara • "+str(mission[10]),"item":"Ambil "+str(mission[2]),"clue":"Periksa "+str(mission[4]),"console":mission[9],"hide":"Bersembunyi","exit":"Lanjutkan","door":"Periksa pintu"}
		for j in 3:labels[["reg","voice","paper"][j]]=ARSIP.data[chapter*2][j][0]
		action_label.text="E   "+str(labels.get(focus,"Periksa"))

func show_slot(idx:int):
	if idx>=cargo.size():
		say("Slot kosong.")
		return
	say("Barang %d · %s"%[idx+1,cargo[idx]])

func _exit_tree():
	for audio_player in [music,storm,radio]:
		if is_instance_valid(audio_player):audio_player.stop()

func _unhandled_input(ev):
	if state=="play" and ev is InputEventMouseMotion and not hiding:
		var sens:float=.00065+.000032*options["Sensitivitas mouse"]
		player.rotate_y(-ev.relative.x*sens)
		pitch=clampf(pitch-ev.relative.y*sens,-1.32,1.32)
		camera.rotation.x=pitch
	if not (ev is InputEventKey and ev.pressed and not ev.echo):return
	if state=="play":
		match ev.physical_keycode:
			KEY_ESCAPE:pause_menu()
			KEY_1:show_slot(0)
			KEY_2:show_slot(1)
			KEY_3:show_slot(2)
			KEY_I: inventory()
			KEY_J: journal()
			KEY_M: map_view()
			KEY_F:lamp.visible=not lamp.visible and battery>0
			KEY_E:interact()
	elif ev.physical_keycode==KEY_ESCAPE:
		if state in ["pause","inventory","journal","map","code","dialogue","bench"]:resume()
		elif state=="settings":main_menu() if prior=="menu" else pause_menu()
		elif state=="credits":main_menu()

func _physics_process(dt):
	if state!="play":return
	clock+=dt
	grace=maxf(0,grace-dt)
	caption_left-=dt
	if caption_left<0:subtitle.text=""
	if not hiding:
		var axis:=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W))).normalized()
		var running:=Input.is_physical_key_pressed(KEY_SHIFT) and stamina>1 and axis.length()>0
		var dir:=player.transform.basis*Vector3(axis.x,0,axis.y)
		player.velocity.x=dir.x*(4.4 if running else 2.35)
		player.velocity.z=dir.z*(4.4 if running else 2.35)
		player.velocity.y-=12*dt
		player.move_and_slide()
		camera.position.y=1.54+(.021*sin(clock*(13 if running else 9)) if player.is_on_floor() and axis.length()>0 else 0.0)
		stamina=clampf(stamina+(-17.0 if running else 9.0)*dt,0,100)
		step_left-=dt
		if axis.length()>0 and player.is_on_floor() and step_left<=0:
			play_sound("langkah",player.position,.72 if running else .45)
			step_left=.34 if running else .52
		if running:noise_left=1
	else:stamina=minf(100,stamina+12*dt)
	noise_left=maxf(0,noise_left-dt)
	if lamp.visible:
		battery=maxf(0,battery-.16*dt)
		if battery<=0:lamp.visible=false
	else:battery=minf(100,battery+.34*dt)
	if is_instance_valid(enemy):ghost_step(dt)
	if state!="play":return
	focus=target()
	update_hud()

func target()->String:
	var best:=0.48
	var chosen:=""
	for key in tags:
		if (key=="exit" and (not flags.open or player.position.z>gate.position.z-.1)) or (key=="door" and flags.open) or (key=="item" and flags.item):continue
		var spot:Vector3=tags[key].global_position
		if key in ["talk","hide","door","console"]:spot.y+=1.12
		var ray:=spot-camera.global_position
		if ray.length()>3.05:continue
		var score:=(-camera.global_transform.basis.z).dot(ray.normalized())-.04*ray.length()
		if score>best:
			var query:=PhysicsRayQueryParameters3D.create(camera.global_position,spot)
			query.exclude=[player.get_rid(),gate.get_rid()]
			var hit:=get_world_3d().direct_space_state.intersect_ray(query)
			if not hit.is_empty() and hit.position.distance_to(spot)>.24:continue
			best=score
			chosen=key
	return chosen

func ghost_step(dt:float):
	var dist:=enemy.position.distance_to(player.position)
	var prev:=chase
	if hiding or grace>0 or dist>11:chase=false
	elif dist<(7.0 if noise_left>0 or lamp.visible else 3.5):chase=true
	var dest:=player.position if chase else Vector3(.45*sin(clock*.28),0,-16+7*sin(clock*.22))
	dest.y=0
	var diff:=dest-enemy.position
	if diff.length()>.04:
		enemy.look_at(dest,Vector3.UP,true)
		enemy.position=enemy.position.move_toward(dest,dt*(2.76 if chase else 1.08))
	if prev!=chase:
		animate(enemy,"running" if chase else "walking")
		if chase:
			play_sound("bisik",enemy.position,.92)
			say("Langkah di belakangmu semakin dekat.",2)
	if chase and dist<.83 and not hiding:
		health-=34
		if health<=0:
			panel("lost","Lintasan 13","Tertinggal")
			textline("Pintu gerbong menutup. Coba lagi dari awal bab, atau lanjutkan dari simpanan.")
			button("Ulangi bab ini",func():health=100;start_chapter(chapter))
			if FileAccess.file_exists(SAVE):button("Muat simpanan",load_game)
		else:
			enemy.position.z=-20
			grace=6
			say("Terkena bayangan. Menjauh atau cari tempat bersembunyi.")

func play_sound(id:String,pos:Vector3,gain:float):
	var a:=AudioStreamPlayer3D.new()
	level.add_child(a)
	a.position=pos+Vector3.UP
	a.stream=load("res://audio/"+id+".wav")
	a.bus="Efek"
	a.volume_db=linear_to_db(gain)
	a.finished.connect(a.queue_free)
	a.play()

func record(s):
	if not history.has(s):history.append(s)

func interact():
	if hiding:
		hiding=false
		camera.position.y=1.54
		grace=2
		return
	focus=target()
	match focus:
		"reg","voice","paper":
			var rec=ARSIP.data[chapter*2][["reg","voice","paper"].find(focus)]
			flags[focus]=true
			record(str(rec[0])+" · "+str(rec[1]))
			panel("dialogue","Bukti   /   "+str(mission[0]),rec[0])
			textline(rec[1])
			if focus=="voice":play_sound("klik",player.position,0.85)
			button("Catat dalam jurnal",resume)
		"talk":
			flags.talk=true
			record(str(mission[10])+" · "+str(mission[11]))
			panel("dialogue","Bab %d  /  Percakapan"%(chapter+1),mission[10])
			textline(mission[11])
			button("Akhiri percakapan",resume)
		"item":
			flags.item=true
			tags.item.visible=false
			if not cargo.has(mission[2]):cargo.append(mission[2])
			record("Diambil · "+str(mission[2]))
			play_sound("klik",player.position,.8)
			say("Disimpan: "+str(mission[2]))
		"clue":
			flags.clue=true
			record(mission[7])
			panel("dialogue","Dokumen ditemukan",mission[4])
			textline(mission[7])
			button("Simpan di jurnal",resume)
		"console":
			if flags.open:say("Panel sudah aktif.")
			elif not (flags.item and flags.clue and flags.talk):say(objective())
			elif not (flags.get("reg") and flags.get("voice") and flags.get("paper")):say(objective())
			elif flags.get("code"):bench.draw()
			elif not flags.get("dispatch"):inspection(0)
			else:code_panel()
		"hide":
			hiding=true
			chase=false
			camera.position.y=.83
			lamp.visible=false
			say("Kamu berlindung di balik bagasi.")
		"door":say("Pintu terkunci. "+objective())
		"exit":
			if flags.open:
				if chapter<5:start_chapter(chapter+1)
				else:choice_ending()

func inspection(step:int):
	var q=ARSIP.data[chapter*2+1][step]
	panel("code","Verifikasi arsip    /    %d dari 3"%(step+1),"Pemeriksaan dinas")
	textline(q[0])
	for choice in 3:
		button(q[choice+1],func():
			if choice==int(q[4]):
				if step<2:inspection(step+1)
				else:
					flags.dispatch=true
					code_panel()
			else:
				panel("dialogue","Arsip tidak cocok","Periksa kesaksian")
				textline("Mesin menolak catatan. Bandingkan jawabanmu dengan tiga bukti di jurnal.")
				button("Baca jurnal",journal)
				button("Coba lagi",func():inspection(step)))
	button("Kembali",resume)

func code_panel():
	panel("code","Panel kendali   /   AR-13",mission[6])
	textline("Masukkan empat angka. Petunjuk yang kamu temukan:")
	textline(mission[7])
	var input:=LineEdit.new()
	input.placeholder_text="0 0 0 0"
	input.max_length=4
	input.custom_minimum_size=Vector2(235,46)
	box.add_child(input)
	var response:=label(box,"",16,GOLD)
	var check:=func():
		if input.text==mission[8]:
			flags.code=true
			bench.draw()
		else:
			response.text="Kode ditolak. Periksa kembali angka pada dokumen."
			input.select_all()
	button("Aktifkan relai",check)
	button("Kembali",resume)
	input.text_submitted.connect(func(_s):check.call())
	input.grab_focus()

func unlock():
	flags.open=true
	gate.collision_layer=0
	tags.door.position.x=-1.84
	play_sound("klik",tags.console.position,1)

func choice_ending():
	panel("ending_choice","Meja sinyal   /   Stasiun Terakhir","Dua jalur")
	textline("Mira menunggu di tepi peron. Rel terakhir bercabang di balik kabut.")
	button("Jalur 01  ·  Kembalikan kereta ke Stasiun Kota",func():ending(false))
	button("Jalur 02  ·  Bebaskan penumpang",func():ending(true))

func ending(free:bool):
	panel("ending","Akhir perjalanan   /   "+("II" if free else "I"),"Pulang" if free else "Putaran berikutnya",true)
	textline("Jam stasiun bergerak lagi. Di balik kaca gerbong, Mira mengangkat tiketnya untuk terakhir kali." if free else "Pengeras suara menyebut pukul 23.47. Saat pintu terbuka, wajahmu telah tercetak pada manifes kereta.")
	button("Kembali ke menu utama",main_menu)

func inventory():
	panel("inventory","Barang bukti  /  %02d dari 20"%cargo.size(),"Inventaris")
	var grid:=GridContainer.new()
	grid.columns=5
	box.add_child(grid)
	var detail:=Label.new()
	for i in 20:
		var b:=Button.new()
		grid.add_child(b)
		b.custom_minimum_size=Vector2(110,56)
		if i<cargo.size():
			var name_item:String=cargo[i]
			var ids: Array=[28,45,41,28,44,39]
			for j in DATA.data.size():
				if DATA.data[j][2]==name_item:
					b.icon=load("res://runtime/item%d.png"%ids[j])
					b.expand_icon=true
					break
			b.tooltip_text=name_item
			b.pressed.connect(func():detail.text=name_item+" · Dikumpulkan dalam perjalanan dinas Arunika 13.")
		else:
			b.text="—"
			b.disabled=true
	box.add_child(detail)
	button("Kembali",resume)

func journal():
	panel("journal","Catatan Raka","Jurnal perjalanan")
	textline("Tujuan aktif · "+objective())
	var row:=HBoxContainer.new()
	box.add_child(row)
	var nav:=VBoxContainer.new()
	nav.custom_minimum_size.x=210
	row.add_child(nav)
	var doc:=label(row,"Pilih catatan untuk membaca kembali kesaksian.",20,GOLD)
	doc.custom_minimum_size.x=400
	doc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	for i in history.size():
		var entry:=str(history[i])
		var pick:=Button.new()
		pick.text="%02d    "%(i+1)+entry.left(23)
		nav.add_child(pick)
		pick.pressed.connect(func():doc.text=entry)
	if history.size():doc.text=str(history.back())
	button("Kembali",resume)

func map_view():
	panel("map","Jaringan Arunika","Peta lintasan")
	var denah:=TextureRect.new()
	box.add_child(denah)
	denah.texture=load("res://runtime/denah.png")
	denah.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	denah.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT
	denah.custom_minimum_size=Vector2(490,320)
	for i in DATA.data.size():label(box,("●    " if i==chapter else "│    ")+("%02d    "%(i+1))+str(DATA.data[i][0]),22,GOLD if i==chapter else PALE)
	textline("Bukti arsip · "+("Loket dinas → Arsip → Ruang tunggu. Masuk melalui tiga bukaan di sisi barat peron." if chapter in [0,5] else "Register di rak kiri depan, radio di kanan tengah, surat di rak kiri belakang."))
	textline("Meja petugas di sisi kiri. Dokumen di sisi kanan. Panel sinyal berada di ujung tiap lintasan.")
	button("Kembali",resume)

func pause_menu():
	panel("pause","Perjalanan dihentikan","Jeda")
	button("Lanjutkan",resume)
	button("Simpan permainan",save_game)
	button("Pengaturan",func():settings("pause"))
	button("Kembali ke menu utama",main_menu)

func save_game():
	var f:=FileAccess.open(SAVE,FileAccess.WRITE)
	if f==null:
		textline("Gagal membuka folder penyimpanan.")
		return
	var p:=player.position
	f.store_string(JSON.stringify({"chapter":chapter,"flags":flags,"cargo":cargo,"history":history,"pos":[p.x,p.y,p.z],"yaw":player.rotation.y,"pitch":pitch,"health":health,"battery":battery,"stamina":stamina,"lamp":lamp.visible}))
	f.close()
	resume()
	say("Permainan tersimpan.")

func load_game():
	var data=JSON.parse_string(FileAccess.get_file_as_string(SAVE))
	if not data is Dictionary or not data.has("pos") or data.pos.size()!=3:
		main_menu()
		textline("Simpanan tidak dapat dibaca.")
		return
	start_chapter(clampi(int(data.chapter),0,5))
	flags.merge(data.flags,true)
	cargo=data.cargo
	history=data.history
	player.position=Vector3(data.pos[0],data.pos[1],data.pos[2])
	player.rotation.y=data.yaw
	pitch=data.pitch
	camera.rotation.x=pitch
	health=int(data.health)
	battery=data.battery
	stamina=data.stamina
	lamp.visible=data.lamp
	tags.item.visible=not flags.item
	if flags.open:unlock()
	update_hud()
