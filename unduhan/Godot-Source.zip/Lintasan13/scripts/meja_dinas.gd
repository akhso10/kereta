extends RefCounted
# The panel is transient. Each chapter owns a different piece of railway equipment.
var game
var turns := [1,0,2,1,0,2]
var seats := ["Raka","Mira","Darma","Nara"]
var loads := [false,false,false,false,false]
var dial := 982
var band := 0
var sequence: Array[int] = []
var order: Array[String] = []
var pulse_id := 0
var feedback := ""
const NAMES = ["Wesel barat","Manifes kursi","Radio kabin","Timbangan bagasi","Isyarat terowongan","Urutan keberangkatan"]
const WEIGHTS = [3,5,8,11,14]
const FORMS = ["Kunci petugas","Tas kanvas","Koper kulit","Kotak alat","Peti arsip"]
const SIGNAL = [0,2,1,2,0]
const COLORS = ["Merah","Kuning","Hijau"]
func setup(owner):
	game=weakref(owner)

func draw():
	var g=game.get_ref()
	g.panel("bench","Meja dinas   /   "+str(g.mission[0]),NAMES[g.chapter])
	match g.chapter:
		0:relay(g)
		1:manifest(g)
		2:tune(g)
		3:scales(g)
		4:signals(g)
		5:dispatch(g)
	if feedback!="":g.textline(feedback)
	g.button("Tinggalkan meja",g.resume)

func finish():
	var g=game.get_ref()
	g.flags.bench=true
	g.unlock()
	g.record("Selesai · "+str(g.mission[9]))
	g.resume()
	g.say("Sinyal diterima. Pintu di ujung lintasan terbuka.",5)

func retry(s):
	feedback=s
	draw()

func relay(g):
	# West enters A. A → B → E → F is the only connected route to the east exit.
	g.textline("Masukkan arus dari kiri A dan keluarkan dari kanan F. Klik satu keping untuk memutarnya 90°. Cabang buntu boleh diabaikan.")
	var grid:=GridContainer.new()
	grid.columns=3
	g.box.add_child(grid)
	var kinds=[0,1,1,1,1,0]
	for i in 6:
		var b:=Button.new()
		grid.add_child(b)
		var glyphs=["━","┃","━","┃"] if kinds[i]==0 else ["┏","┓","┛","┗"]
		b.text=str(["A","B","C","D","E","F"][i])+"   "+glyphs[turns[i]%4]
		b.custom_minimum_size=Vector2(128,50)
		b.pressed.connect(func():turns[i]=(turns[i]+1)%4;feedback="";draw())
	g.button("Uji aliran",func():
		var dirs=[Vector2i.RIGHT,Vector2i.DOWN,Vector2i.LEFT,Vector2i.UP]
		var cur=Vector2i.ZERO
		var incoming=2
		var seen=[]
		while cur.x>=0 and cur.x<3 and cur.y>=0 and cur.y<2:
			var idx=cur.y*3+cur.x
			if idx in seen:break
			seen.append(idx)
			var ports=[(turns[idx]+0)%4,(turns[idx]+(2 if kinds[idx]==0 else 1))%4]
			if incoming not in ports:break
			var next=ports[1] if ports[0]==incoming else ports[0]
			if idx==5 and next==0:finish();return
			cur+=dirs[next]
			incoming=(next+2)%4
		retry("Lampu padam. Arus terhenti setelah keping "+str(["A","B","C","D","E","F"][seen.back()])+"."))

func manifest(g):
	g.textline("Susun empat nama dari kiri ke kanan. Mira di kursi paling kiri. Nara tepat di kanan Darma. Raka duduk di antara Mira dan Darma.")
	for i in 4:
		var j=(i+1)%4
		g.button("%02d    %s    ⇄    %02d"%[i+1,seats[i],j+1],func():
			var t=seats[i]
			seats[i]=seats[j]
			seats[j]=t
			feedback=""
			draw())
	g.button("Cap manifes",func():
		if seats==["Mira","Raka","Darma","Nara"]:finish()
		else:retry("Susunan belum cocok dengan keterangan kondektur."))

func tune(g):
	var target=[1003,1047][band]
	g.textline("Dengarkan dua kanal secara berurutan. Kanal menara berada 0,3 MHz di atas 100. Kanal kabin tercatat pada kartu frekuensi.")
	g.textline("KANAL %d    /    %.1f MHz     •     Kekuatan sinyal %d%%"%[band+1,dial/10.0,maxi(0,100-absi(target-dial)*6)])
	for value in [-10,-1,1,10]:
		g.button("%+.1f MHz"%(value/10.0),func():dial=clampi(dial+value,950,1090);feedback="";draw())
	g.button("Kunci kanal",func():
		if dial!=target:retry("Desis statis. Sesuaikan gelombang sampai kekuatan sinyal penuh.")
		elif band==0:
			band=1
			g.play_sound("klik",g.player.position,.75)
			retry("Menara menjawab. Sekarang cari kanal kabin.")
		else:finish())

func scales(g):
	g.textline("Muatan yang bisa diangkut tepat 19 kg. Surat perintah meminta koper kulit dan satu barang dinas. Pilih barang yang akan ditimbang.")
	var weight=0
	for i in 5:
		if loads[i]:weight+=WEIGHTS[i]
		g.button(("%s    %s   ·   %d kg"%["●" if loads[i] else "○",FORMS[i],WEIGHTS[i]]),func():loads[i]=not loads[i];feedback="";draw())
	g.textline("Timbangan   %d / 19 kg"%weight)
	g.button("Segel muatan",func():
		if loads[2] and loads[3] and loads.count(true)==2:finish()
		else:retry("Berat dan isi kiriman harus sesuai surat perintah."))

func signals(g):
	g.textline("Balas lima pulsa dari menara. Baca dari kiri ke kanan. Merah = satu, kuning = dua, hijau = tiga.")
	g.button("Putar sinyal",replay)
	for i in 3:g.button(COLORS[i],func():
		sequence.append(i)
		if sequence.back()!=SIGNAL[sequence.size()-1]:
			sequence.clear()
			retry("Sandi terputus. Putar lagi dan mulai dari pulsa pertama.")
		elif sequence.size()==SIGNAL.size():finish()
		else:retry("%d dari 5 pulsa diterima."%sequence.size()))

func replay():
	pulse_id+=1
	var version=pulse_id
	var g=game.get_ref()
	sequence.clear()
	var transcript=""
	for i in SIGNAL:
		if not is_instance_valid(g) or g.state!="bench" or version!=pulse_id:return
		transcript+=str(i+1)+"  "
		feedback="Penerima optik   "+transcript
		draw()
		g.play_sound("klik",g.player.position,.75)
		await g.get_tree().create_timer(.55).timeout

func dispatch(g):
	g.textline("Petugas peron menunggu tiga tindakan. Lonceng hanya boleh berbunyi sesudah nama penumpang tercatat. Sebelum mencatat nama, pastikan jalur kedatangan sudah dipilih.")
	for name in ["Bunyikan lonceng","Catat nama Mira","Pilih jalur kedatangan"]:
		g.button(name,func():
			if name in order:retry("Tindakan ini sudah dicatat.");return
			order.append(name)
			if order.size()<3:retry("Urutan tercatat · "+" → ".join(order));return
			if order==["Pilih jalur kedatangan","Catat nama Mira","Bunyikan lonceng"]:finish()
			else:
				order.clear()
				retry("Lonceng tak menjawab. Ulangi menurut berita acara."))
